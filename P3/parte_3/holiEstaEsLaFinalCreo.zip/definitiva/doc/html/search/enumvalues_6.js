var searchData=
[
  ['oca_5ffollowing',['OCA_FOLLOWING',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50cac3988b12a039e31264513788c40ad322',1,'command.h']]],
  ['oca_5fprevious',['OCA_PREVIOUS',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50ca356a23a6d4264f3ba8a5dc3f5a1fa640',1,'command.h']]],
  ['ok',['OK',['../types_8h.html#a32c27cc471df37f4fc818d65de0a56c4a2bc49ec37d6a5715dd23e85f1ff5bb59',1,'types.h']]]
];
