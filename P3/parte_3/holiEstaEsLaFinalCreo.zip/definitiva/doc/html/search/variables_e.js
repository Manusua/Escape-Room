var searchData=
[
  ['resultado_5fanterior',['resultado_anterior',['../struct__Die.html#a838ebc47c53074c54c96edf04d40e3cc',1,'_Die']]],
  ['resultado_5fcomando',['resultado_comando',['../struct__Game.html#ae5043c90b0187cdcef87720f6cdef4ce',1,'_Game']]]
];
