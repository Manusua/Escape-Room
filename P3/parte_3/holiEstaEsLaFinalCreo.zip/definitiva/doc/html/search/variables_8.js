var searchData=
[
  ['id',['id',['../struct__Die.html#a0887af562dda760409957f13619d36f1',1,'_Die::id()'],['../struct__Link.html#a151212e7a8e8274c2a1ee991ba95878b',1,'_Link::id()'],['../struct__Object.html#a3cff7a0e8dc4e9d23895ed9af1b7653a',1,'_Object::id()'],['../struct__Player.html#a60d635cd063816a9c1bd873f4868bb90',1,'_Player::id()'],['../struct__Set.html#aaa814a92620bfdb539ed25be204a3079',1,'_Set::id()'],['../struct__Space.html#a70cb461deb9ac073e401b607339b567f',1,'_Space::id()']]],
  ['id_5fconexion',['id_conexion',['../struct__Link.html#a9ea47d0c17026ae0e038fca89cd6fb7b',1,'_Link']]],
  ['inventory',['inventory',['../struct__Player.html#a5e02924cb82ca61f74ba414d190aa29b',1,'_Player']]]
];
