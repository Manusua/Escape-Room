var searchData=
[
  ['object',['object',['../struct__Game.html#a8ade6d831e4710c40b0d61004bbd1585',1,'_Game']]],
  ['objects',['objects',['../struct__Inventory.html#a478e4b50a62b9e7d5b17e335319faa97',1,'_Inventory']]]
];
