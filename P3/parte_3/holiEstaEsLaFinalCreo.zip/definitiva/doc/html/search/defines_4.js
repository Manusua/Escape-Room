var searchData=
[
  ['max_5flink',['MAX_LINK',['../game_8h.html#abfa744c8ca5b46f7f2a10aea53a4ec59',1,'game.h']]],
  ['max_5fobject',['MAX_OBJECT',['../game_8h.html#a7083b26c57d956d72197b9428d8e4894',1,'game.h']]],
  ['max_5fspaces',['MAX_SPACES',['../space_8h.html#a5f54fd55f983a2e33ce076cd9f587e82',1,'space.h']]]
];
