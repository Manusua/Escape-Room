var searchData=
[
  ['t_5fcommand',['T_Command',['../command_8h.html#a0473597db8c45c0289b6b8e2f8abbe32',1,'command.h']]],
  ['take',['TAKE',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50ca7405647410e343caba1bf383e83d4f5f',1,'command.h']]],
  ['tam',['tam',['../struct__Inventory.html#ae6dad9356e59d5e9ce48b09861be1516',1,'_Inventory::tam()'],['../types_8h.html#ae0b4816fb45161ef9da5e6d6134ee28a',1,'TAM():&#160;types.h']]],
  ['tam_5fcasilla',['TAM_CASILLA',['../graphic__engine_8h.html#aad732d3eb468a71e3179db5799c19238',1,'graphic_engine.h']]],
  ['tam_5fdibujo',['TAM_DIBUJO',['../space_8h.html#a894ebc9b2098fe63607e0ca2e5f5ce8d',1,'space.h']]],
  ['tam_5fdibujo_5flinea',['TAM_DIBUJO_LINEA',['../space_8h.html#ad29ae39d7c9da97f682d80fcee3e9fa4',1,'space.h']]],
  ['tam_5fset',['TAM_SET',['../set_8h.html#a24b51e1a036e3b382adcc8216239aafd',1,'set.h']]],
  ['tam_5ftotal_5fcasilla',['TAM_TOTAL_CASILLA',['../graphic__engine_8h.html#aa2d6ccbb8c91b54681c0f1dcc1b59441',1,'graphic_engine.h']]],
  ['total_5fdata',['TOTAL_DATA',['../screen_8c.html#afba5c5b9f73273ce653f890bb64740b0',1,'screen.c']]],
  ['true',['TRUE',['../types_8h.html#a3e5b8192e7d9ffaf3542f1210aec18ddaa82764c3079aea4e60c80e45befbb839',1,'types.h']]],
  ['types_2eh',['types.h',['../types_8h.html',1,'']]]
];
