var searchData=
[
  ['die_5fcreate',['die_create',['../die_8c.html#a7edfb04683a77471c710342df00b7562',1,'die_create():&#160;die.c'],['../die_8h.html#a7edfb04683a77471c710342df00b7562',1,'die_create():&#160;die.c']]],
  ['die_5fdestroy',['die_destroy',['../die_8c.html#a0155d7ec003966bace47f3e032a368e8',1,'die_destroy(Die *die):&#160;die.c'],['../die_8h.html#a0155d7ec003966bace47f3e032a368e8',1,'die_destroy(Die *die):&#160;die.c']]],
  ['die_5fget_5fid',['die_get_id',['../die_8c.html#a57c9a2627bb3a1ca04fe55d72bd6a5ea',1,'die_get_id(Die *die):&#160;die.c'],['../die_8h.html#a57c9a2627bb3a1ca04fe55d72bd6a5ea',1,'die_get_id(Die *die):&#160;die.c']]],
  ['die_5fget_5fresultado_5fanterior',['die_get_resultado_anterior',['../die_8c.html#a2dc38f9995bcb95189516f780ba51ebd',1,'die_get_resultado_anterior(Die *die):&#160;die.c'],['../die_8h.html#a2dc38f9995bcb95189516f780ba51ebd',1,'die_get_resultado_anterior(Die *die):&#160;die.c']]],
  ['die_5fprint',['die_print',['../die_8c.html#adb0fa0ace96ca78efc3c0b191293e005',1,'die_print(FILE *f, Die *die):&#160;die.c'],['../die_8h.html#adb0fa0ace96ca78efc3c0b191293e005',1,'die_print(FILE *f, Die *die):&#160;die.c']]],
  ['die_5fset_5fid',['die_set_id',['../die_8c.html#a9062d99f612a9779903e9856c96db9d4',1,'die_set_id(Die *die, Id id):&#160;die.c'],['../die_8h.html#a9062d99f612a9779903e9856c96db9d4',1,'die_set_id(Die *die, Id id):&#160;die.c']]]
];
