var searchData=
[
  ['resultado_5fanterior',['resultado_anterior',['../struct__Die.html#a838ebc47c53074c54c96edf04d40e3cc',1,'_Die']]],
  ['resultado_5fcomando',['resultado_comando',['../struct__Game.html#ae5043c90b0187cdcef87720f6cdef4ce',1,'_Game']]],
  ['roll',['ROLL',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50ca2eeb9fef8a6a516fa6437a44a6efbd52',1,'command.h']]],
  ['roll_5fdie',['roll_die',['../die_8c.html#af535a5abb87f07b4b89800478035b69c',1,'roll_die(Die *die):&#160;die.c'],['../die_8h.html#af535a5abb87f07b4b89800478035b69c',1,'roll_die(Die *die):&#160;die.c']]],
  ['rows',['ROWS',['../screen_8c.html#a3cfd3aa62338d12609f6d65bce97e9cd',1,'screen.c']]]
];
