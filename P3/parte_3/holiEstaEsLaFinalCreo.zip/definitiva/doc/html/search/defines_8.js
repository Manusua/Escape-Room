var searchData=
[
  ['screen_5fmax_5fstr',['SCREEN_MAX_STR',['../screen_8h.html#aab63df3ae7b979d59ea0188055ea0763',1,'screen.h']]]
];
