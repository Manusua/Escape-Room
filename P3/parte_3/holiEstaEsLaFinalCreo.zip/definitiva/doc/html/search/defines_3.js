var searchData=
[
  ['fg_5fchar',['FG_CHAR',['../screen_8c.html#a0bbf43d51e6cd6f7119cf1d0063a3a94',1,'screen.c']]],
  ['first_5fspace',['FIRST_SPACE',['../space_8h.html#a088cbe7c6f78264d46c2624194c5c680',1,'space.h']]]
];
