var searchData=
[
  ['object',['object',['../struct__Game.html#a8ade6d831e4710c40b0d61004bbd1585',1,'_Game::object()'],['../object_8h.html#a7f8bbcda919b65ce67f92fba08e0212f',1,'Object():&#160;object.h']]],
  ['object_2ec',['object.c',['../object_8c.html',1,'']]],
  ['object_2eh',['object.h',['../object_8h.html',1,'']]],
  ['object_5fcreate',['object_create',['../object_8c.html#a2dd568a27239e988cdde871cfb30e166',1,'object_create():&#160;object.c'],['../object_8h.html#a2dd568a27239e988cdde871cfb30e166',1,'object_create():&#160;object.c']]],
  ['object_5fdestroy',['object_destroy',['../object_8c.html#a2f26d467bceeedc73132eff682bdeb76',1,'object_destroy(Object *object):&#160;object.c'],['../object_8h.html#a527a907ec8168d6076b8ad76ec06a8a3',1,'object_destroy(Object *):&#160;object.c']]],
  ['object_5fget_5fdescription',['object_get_description',['../object_8c.html#ab92f583fcb6e3000ebe48cc04c5853cd',1,'object_get_description(Object *object):&#160;object.c'],['../object_8h.html#ab92f583fcb6e3000ebe48cc04c5853cd',1,'object_get_description(Object *object):&#160;object.c']]],
  ['object_5fget_5fid',['object_get_id',['../object_8c.html#ac5af152381a21853c6a28cc120e8e7fe',1,'object_get_id(Object *object):&#160;object.c'],['../object_8h.html#ac5af152381a21853c6a28cc120e8e7fe',1,'object_get_id(Object *object):&#160;object.c']]],
  ['object_5fget_5fname',['object_get_name',['../object_8c.html#a7954dbdd53d8b5dc259993f04bba28f8',1,'object_get_name(Object *object):&#160;object.c'],['../object_8h.html#a1a5d42ae09cf6c48dbc452e1c682d8d7',1,'object_get_name(Object *):&#160;object.c']]],
  ['object_5fprint',['object_print',['../object_8c.html#a9706d7bb1dd6b0a322ffeef034f65e0e',1,'object_print(FILE *f, Object *object):&#160;object.c'],['../object_8h.html#a9706d7bb1dd6b0a322ffeef034f65e0e',1,'object_print(FILE *f, Object *object):&#160;object.c']]],
  ['object_5fset_5fdescription',['object_set_description',['../object_8c.html#ae88627a8873d8f08fba9c0470a19cfc0',1,'object_set_description(Object *object, char *description):&#160;object.c'],['../object_8h.html#ae88627a8873d8f08fba9c0470a19cfc0',1,'object_set_description(Object *object, char *description):&#160;object.c']]],
  ['object_5fset_5fid',['object_set_id',['../object_8c.html#a583e26f5ce36b881294544c2e5751545',1,'object_set_id(Object *object, Id nuevo_id):&#160;object.c'],['../object_8h.html#a583e26f5ce36b881294544c2e5751545',1,'object_set_id(Object *object, Id nuevo_id):&#160;object.c']]],
  ['object_5fset_5fname',['object_set_name',['../object_8c.html#a7380846ad2114ea6c10087dbbd48b672',1,'object_set_name(Object *object, char *nuevo_nombre):&#160;object.c'],['../object_8h.html#a7380846ad2114ea6c10087dbbd48b672',1,'object_set_name(Object *object, char *nuevo_nombre):&#160;object.c']]],
  ['objects',['objects',['../struct__Inventory.html#a478e4b50a62b9e7d5b17e335319faa97',1,'_Inventory']]],
  ['oca_5ffollowing',['OCA_FOLLOWING',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50cac3988b12a039e31264513788c40ad322',1,'command.h']]],
  ['oca_5fprevious',['OCA_PREVIOUS',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50ca356a23a6d4264f3ba8a5dc3f5a1fa640',1,'command.h']]],
  ['ok',['OK',['../types_8h.html#a32c27cc471df37f4fc818d65de0a56c4a2bc49ec37d6a5715dd23e85f1ff5bb59',1,'types.h']]]
];
