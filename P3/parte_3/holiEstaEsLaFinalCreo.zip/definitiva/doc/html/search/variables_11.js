var searchData=
[
  ['ultima_5fdescripcion_5fpedida',['ultima_descripcion_pedida',['../struct__Game.html#ada8be61bb88218238ba6d17918b199aa',1,'_Game']]]
];
