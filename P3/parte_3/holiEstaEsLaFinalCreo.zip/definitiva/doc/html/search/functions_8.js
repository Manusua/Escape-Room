var searchData=
[
  ['roll_5fdie',['roll_die',['../die_8c.html#af535a5abb87f07b4b89800478035b69c',1,'roll_die(Die *die):&#160;die.c'],['../die_8h.html#af535a5abb87f07b4b89800478035b69c',1,'roll_die(Die *die):&#160;die.c']]]
];
