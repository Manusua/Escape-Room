var searchData=
[
  ['tam',['tam',['../struct__Inventory.html#ae6dad9356e59d5e9ce48b09861be1516',1,'_Inventory']]]
];
