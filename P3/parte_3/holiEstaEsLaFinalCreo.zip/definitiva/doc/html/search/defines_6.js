var searchData=
[
  ['prompt',['PROMPT',['../screen_8c.html#accdbea14ea06c15e271784368bd993e8',1,'screen.c']]]
];
